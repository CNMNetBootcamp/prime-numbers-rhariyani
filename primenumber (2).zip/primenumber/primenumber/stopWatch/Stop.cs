﻿namespace stopWatch
{
    internal class Stop
    {
    }
}