﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Linq;
using System.Text;



namespace primenumber
{
    class Program
    {


        static void Main(string[] args)

        {


            //int[] n = new int[100];
            int i, j;

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();


            bool isPrime = true;

            Console.WriteLine("Prime Numbers");

            for (i = 1; i <= 100; i++)// i = to start interval form 1 to 100

            {
                for (j = 2; j<=i-1; j++)// j helps to compare the value of 2 as modulu

                {
                    if ( i % j == 0)
                    {

                        isPrime = false;
                        break;

                    }
                    if (isPrime)
                    {
                        Console.WriteLine("The prime number :"+i);
                       
                    }
                    isPrime = true;
                }


            }
            Console.ReadLine();
            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            Console.WriteLine("Total count: " + i);
            Console.WriteLine("The stop watch recorded " + ts + " seconds");
            Console.ReadLine();
           





        }
    }
}
















